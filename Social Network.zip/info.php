<?php
// Software Name
$name = 'Lý Trần';

// Software Author
$author = 'Lý Trần';

// Software URL
$url = 'https://lytran98.github.io/lytran.com';

// Software Version
//$version = '3.0.8';
?>