<?php
// Language Name
$name = 'English';

// Language Author
$author = 'phpSocial';

// Language URL
$url = 'http://phpsocial.com';

$LNG['lang_direction'] = 'ltr';

$LNG['user_success'] = 'Người dùng đã được tạo thành công';
$LNG['user_exists'] = 'Tên người dùng này đã tồn tại';
$LNG['email_exists'] = 'Email này đã được sử dụng';
$LNG['all_fields'] = 'Tất cả các trường là bắt buộc';
$LNG['user_alnum'] = 'Tên người dùng chỉ được bao gồm các chữ cái và số';
$LNG['user_too_short'] = 'Tên người dùng phải có từ 3 đến 32 ký tự';
$LNG['user_limit'] = 'Quá nhiều tài khoản được tạo từ IP này';
$LNG['invalid_email'] = 'Email không hợp lệ';
$LNG['invalid_user_pw'] = 'Sai username hoặc password';
$LNG['invalid_captcha'] = 'Hình ảnh xác thực không hợp lệ';
$LNG['activate_email'] = 'Một liên kết kích hoạt đã được gửi đến email của bạn';
$LNG['account_activated'] = 'Tài khoản của bạn đã được kích hoạt';
$LNG['log_out'] = 'Đăng Xuất';
$LNG['hello'] = 'Xin Chào';
$LNG['register'] = 'Đăng Ký';
$LNG['login'] = 'Đăng Nhập';
$LNG['connect'] = 'Liên kết';
$LNG['password'] = 'Password';
$LNG['username'] = 'Username';
$LNG['email'] = 'Email';
$LNG['captcha'] = 'Captcha';
$LNG['username_or_email'] = 'Username or email';
$LNG['welcome_title'] = 'LT-Social Network';
$LNG['welcome_desc'] = 'Mạng Xã Hội Nơi Kết Nối Cộng Đồng.';
$LNG['welcome_about'] = 'Kết nối, giao lưu, chia sẻ những thông tin hữu ích trên nền tảng Internet.';
$LNG['forgot_password'] = 'Quên mật khẩu?';
$LNG['remember_me'] = 'Remember me';
$LNG['all_rights_reserved'] = 'Đã đăng ký Bản quyền';

$LNG['welcome_one'] = 'Liên kết';
$LNG['welcome_two'] = 'Chia sẻ';
$LNG['welcome_three'] = 'Phát hiện';
$LNG['welcome_one_desc'] = 'Kết nối với gia đình và bạn bè của bạn và chia sẻ những khoảnh khắc của bạn';
$LNG['welcome_two_desc'] = 'Chia sẻ những điều mới mẻ và những khoảnh khắc trong cuộc sống với bạn bè của bạn';
$LNG['welcome_three_desc'] = 'Khám phá những người mới, tạo kết nối mới và kết bạn mới';
$LNG['latest_users'] = 'Người dùng mới nhất';

// NOTIFICATION BOXES
$LNG['settings_saved'] = 'Cài đặt đã lưu';
$LNG['nothing_saved'] = 'Không có gì được lưu';
$LNG['password_changed'] = 'Mật khẩu đã được thay đổi';
$LNG['nothing_changed'] = 'Không có gì thay đổi';
$LNG['incorrect_date'] = 'Ngày đã chọn không hợp lệ, vui lòng chọn ngày hợp lệ.';
$LNG['password_not_changed'] = 'Mật khẩu không được thay đổi.';
$LNG['image_saved'] = 'Đã lưu hình ảnh';
$LNG['error'] = 'Lỗi';
$LNG['no_file'] = 'Bạn đã không chọn bất kỳ tệp nào để tải lên hoặc các tệp đã chọn trống.';
$LNG['file_exceeded'] = 'Kích thước tệp đã chọn không được vượt quá<strong>%s</strong> MB.';
$LNG['file_format'] = 'Định dạng tệp đã chọn không được hỗ trợ. Tải lên <strong>%s</strong> định dạng tệp';
$LNG['image_removed'] = 'Đã xóa hình ảnh';
$LNG['bio_description'] = 'Mô tả Bio phải có % s ký tự trở xuống.';
$LNG['valid_email'] = 'Vui lòng nhập email hợp lệ.';
$LNG['valid_url'] = 'Vui lòng nhập định dạng URL hợp lệ.';
$LNG['valid_country'] = 'Vui lòng nhập một quốc gia hợp lệ.';
$LNG['password_too_short'] = 'Mật khẩu phải chứa ít nhất 6 ký tự.';
$LNG['password_not_match'] = 'Mật khẩu không khớp.';
$LNG['wrong_current_password'] = 'Mật khẩu hiện tại bạn đã nhập không chính xác.';
$LNG['username_not_found'] = 'Chúng tôi không thể tìm thấy tên người dùng đã chọn.';
$LNG['userkey_not_found'] = 'Tên người dùng hoặc khóa đặt lại không đúng, hãy đảm bảo rằng bạn đã nhập đúng thông tin đăng nhập.';
$LNG['password_reseted'] = 'Bạn đã đặt lại mật khẩu thành công, bây giờ bạn có thể đăng nhập bằng thông tin đăng nhập mới.';
$LNG['email_sent'] = 'Đã gửi email';
$LNG['email_reset'] = 'Một email chứa hướng dẫn đặt lại mật khẩu đã được gửi. Vui lòng đợi chúng tôi tối đa 24 giờ để gửi thư, đồng thời kiểm tra hộp Thư rác nếu bạn không thể tìm thấy trong Hộp thư đến của mình.';
$LNG['user_has_been_deleted'] = 'Người dùng <strong>%s</strong> đã bị xóa.';
$LNG['theme_changed'] = 'Chủ đề đã thay đổi';
$LNG['notif_saved'] = 'Thông báo đã thay đổi';
$LNG['notif_success_saved'] = 'Thông báo đã được cập nhật thành công.';

// MAIL CONTENT
$LNG['welcome_mail'] = 'Chào mừng bạn đến %s';
$LNG['user_created'] = 'Cảm ơn bạn đã tham gia <strong>%s</strong>.<br /><br />Tên người dùng của bạn: <strong>%s</strong><br />Mật khẩu của bạn: <strong>%s</strong><br /><br />You can log-in at: <a href="%s" target="_blank">%s</a>';
$LNG['recover_mail'] = 'Khôi phục mật khẩu';
$LNG['recover_content'] = 'Yêu cầu khôi phục mật khẩu, nếu bạn không thực hiện hành động này, vui lòng bỏ qua email này. <br /><br />Tên người dùng của bạn: <strong>%s</strong><br />Khóa đặt lại của bạn: <strong>%s</strong><br /><br />Bạn có thể đặt lại mật khẩu của mình bằng cách truy cập vào phần sau link: <a href="%s" target="_blank">%s</a>';
$LNG['email_hello'] = 'Xin Chào <strong>%s</strong>,<br /><br />';
$LNG['email_unsub'] = '<br /><br /><span style="color: #aaa;">Thư này đã được gửi tự động, nếu bạn không muốn nhận những loại email này từ <strong>%s</strong> trong tương lai, xin vui lòng <a href="%s">Hủy đăng ký</a>.</span>';
$LNG['email_copy'] = '<br /><br /><span style="color: #aaa;">Bản quyền & sao chép; '.date('Y').' <a href="%s">%s</a>. Đã đăng ký Bản quyền.';
$LNG['ttl_comment_email'] = '%s đã nhận xét về tin nhắn của bạn';
$LNG['comment_email'] = $LNG['email_hello'].'<strong><a href="%s">%s</a></strong> đã nhận xét về bạn <strong><a href="%s">thông điệp.</a></strong>'.$LNG['email_unsub'];
$LNG['ttl_like_email'] = '%s đã thích tin nhắn của bạn';
$LNG['like_email'] = $LNG['email_hello'].'<strong><a href="%s">%s</a></strong> thích của bạn <strong><a href="%s">thông điệp.</a></strong>'.$LNG['email_unsub'];
$LNG['ttl_like_c_email'] = '%s thích bình luận của bạn';
$LNG['like_c_email'] = $LNG['email_hello'].'<strong><a href="%s">%s</a></strong> thích của bạn <strong><a href="%s">bình luận.</a></strong>'.$LNG['email_unsub'];
$LNG['ttl_new_friend_email'] = '%s đã gửi cho bạn một lời mời kết bạn';
$LNG['new_friend_email'] = $LNG['email_hello'].'<strong><a href="%s">%s</a></strong> muốn làm bạn trên %s.'.$LNG['email_unsub'];
$LNG['ttl_friendship_confirmed_email'] = '%s chấp nhận yêu cầu kết bạn của bạn';
$LNG['friendship_confirmed_email'] = $LNG['email_hello'].'<strong><a href="%s">%s</a></strong> đã chấp nhận tình bạn của bạn trên %s.'.$LNG['email_unsub'];
$LNG['ttl_page_invite'] = '%s đã mời bạn thích một trang';
$LNG['page_invite'] = $LNG['email_hello'].'<strong><a href="%s">%s</a></strong> đã mời bạn thích <strong><a href="%s">%s</a></strong> trang.'.$LNG['email_unsub'];
$LNG['ttl_group_invite'] = '%s đã mời bạn tham gia một nhóm.';
$LNG['group_invite'] = $LNG['email_hello'].'<strong><a href="%s">%s</a></strong> đã mời bạn tham gia <strong><a href="%s">%s</a> nhóm.</strong>'.$LNG['email_unsub'];
$LNG['ttl_suspended_account_mail'] = 'tài khoản của bạn đã bị tạm khóa';
$LNG['suspended_account_mail'] = $LNG['email_hello'].'Tài khoản của bạn đã bị tạm khóa. Nếu bạn cho rằng đây là lỗi, vui lòng liên hệ với chúng tôi.'.$LNG['email_copy'];
$LNG['ttl_confirm_email'] = 'kích hoạt tài khoản của bạn';
$LNG['confirm_email'] = $LNG['email_hello'].'Cảm ơn bạn đã tham gia <strong>%s</strong>. Hoàn thành đăng ký của bạn trước <a href="%s" target="_blank">clicking here</a>.'.$LNG['email_copy'];

// PHP MODULES
$LNG['openssl_error'] = 'Bạn phải kích hoạt <strong>OpenSSL</strong> phần mở rộng trên máy chủ';
$LNG['curl_error'] = 'Được khuyến khích rằng <strong>cURL</strong> tiện ích mở rộng được bật trên máy chủ';

// ADMIN PANEL
$LNG['general_link'] = 'Chung';
$LNG['security_link'] = 'Bảo vệ';
$LNG['manage_users'] = 'Quản lý người dùng';
$LNG['registration'] = 'Đăng ký';
$LNG['limits'] = 'Hạn mức';
$LNG['emails'] = 'Emails';

$LNG['theme_install'] = 'Để cài đặt chủ đề mới, hãy tải chủ đề đó lên thư mục <strong> chủ đề </strong>';
$LNG['plugin_install'] = 'Để cài đặt một plugin mới, hãy tải nó lên <strong>plugins</strong>';
$LNG['language_install'] = 'Để cài đặt ngôn ngữ mới, hãy tải ngôn ngữ đó lên thư mục <strong> ngôn ngữ </strong>';
$LNG['author_title'] = 'Ghé thăm trang chủ của tác giả';
$LNG['version'] = 'Phiên bản';
$LNG['active'] = 'Active';
$LNG['activate'] = 'Hoạt động';
$LNG['deactivate'] = 'Hủy kích hoạt';
$LNG['by'] = 'Bởi';
$LNG['settings'] = 'Cài đặt';

// FEED
$LNG['welcome_feed_ttl'] = 'Chào mừng bạn đến với Bảng tin của bạn';
$LNG['welcome_feed'] = 'Tất cả các bài đăng từ bạn bè của bạn sẽ xuất hiện trên trang này, hãy bắt đầu bằng cách kết bạn mới.';
$LNG['leave_comment'] = 'Để lại bình luận...';
$LNG['post'] = 'Đăng';
$LNG['view_more_messages'] = 'Tải thêm';
$LNG['view_more_comments'] = 'Xem thêm các bình luận';
$LNG['delete_q_comment'] = 'Bạn có chắc là bạn muốn xoá bình luận này không?';
$LNG['delete_q_message'] = 'Bạn có chắc chắn muốn xóa tin nhắn này?';
$LNG['delete_q_chat'] = 'Bạn có chắc chắn muốn xóa tin nhắn trò chuyện này không?';
$LNG['report_this_comment'] = 'Báo cáo bình luận này';
$LNG['view_more'] = 'Xem thêm';
$LNG['food'] = 'Tôi đang ăn: <strong>%s</strong>';
$LNG['visited'] = 'Tôi đang ở:  <strong>%s</strong>';
$LNG['played'] = 'Tôi đang chơi: <strong>%s</strong>';
$LNG['watched'] = 'Tôi đang xem: <strong>%s</strong>';
$LNG['listened'] = 'Tôi đang nghe: <strong>%s</strong>';
$LNG['shared_title'] = 'đã chia sẻ <a href="%s" rel="loadpage"><strong>%s</strong></a>\'s <a href="%s" rel="loadpage"><strong>tin nhắn</strong></a>.';
$LNG['group_title'] = 'đăng trong <a href="%s" rel="loadpage"><strong>%s</strong></a> nhóm.';
$LNG['form_title'] = 'Cập nhật trạng thái của bạn';
$LNG['comment_wrong'] = 'Đã xảy ra sự cố, vui lòng làm mới trang và thử lại.';
$LNG['comment_too_long'] = 'Xin lỗi, số ký tự tối đa được phép cho mỗi nhận xét là <strong>%s</strong>.';
$LNG['comment_error'] = 'Xin lỗi, chúng tôi không thể đăng nhận xét, vui lòng làm mới trang và thử lại.';
$LNG['message_private'] = 'Xin lỗi, tin nhắn này là riêng tư, chỉ tác giả của tin nhắn mới có thể xem được.';
$LNG['message_private_ttl'] = 'Tin nhắn riêng tư';
$LNG['message_semi_private'] = 'Xin lỗi, tin nhắn này là riêng tư, chỉ bạn bè và tác giả của tin nhắn này mới có thể xem được.';
$LNG['message_semi_private_ttl'] = 'Tin nhắn riêng tư';
$LNG['login_to_lcs'] = 'Đăng nhập để Thích, Bình luận hoặc Chia sẻ';
$LNG['message'] = 'Tin nhắn';
$LNG['comment'] = 'Bình luận';
$LNG['share'] = 'Chia sẻ';
$LNG['camera'] = 'Máy ảnh';
$LNG['capture'] = 'Capture';
$LNG['send'] = 'Gửi';
$LNG['shared_success'] = 'Bài đăng đã được chia sẻ thành công trên của bạn <a href="%s" rel="loadpage"><strong>timeline</strong></a>.';
$LNG['no_shared'] = 'Xin lỗi, không thể chia sẻ tin nhắn này.';
$LNG['share_desc'] = 'Bạn có chắc chắn muốn chia sẻ bài viết này trên dòng thời gian của mình không?';
$LNG['cancel'] = 'Hủy bỏ';
$LNG['close'] = 'Đóng';
$LNG['download'] = 'Tải về';

// REPORT
$LNG['1_not_exists'] = 'Thông báo được báo cáo không tồn tại.';
$LNG['0_not_exists'] = 'Bình luận được báo cáo không tồn tại.';
$LNG['1_already_reported'] = 'Tin nhắn này đã được báo cáo và nó sẽ được xem xét trong thời gian sớm nhất, cảm ơn bạn.';
$LNG['0_already_reported'] = 'Bình luận này đã được báo cáo và nó sẽ được xem xét trong thời gian sớm nhất, cảm ơn bạn.';
$LNG['1_is_safe'] = 'Thư này được quản trị viên đánh dấu là <strong> an toàn </strong>, cảm ơn bạn đã phản hồi.';
$LNG['0_is_safe'] = 'Bình luận này được quản trị viên đánh dấu là <strong> an toàn </strong>, cảm ơn bạn đã phản hồi.';
$LNG['1_report_added'] = 'Tin nhắn đã được báo cáo, cảm ơn bạn đã phản hồi.';
$LNG['0_report_added'] = 'Bình luận đã được báo cáo, cảm ơn bạn đã phản hồi.';
$LNG['1_report_error'] = 'Xin lỗi, đã xảy ra sự cố khi báo cáo thông báo này, vui lòng làm mới trang và thử lại.';
$LNG['0_report_error'] = 'Xin lỗi, đã xảy ra sự cố khi báo cáo nhận xét này, vui lòng làm mới trang và thử lại.';
$LNG['1_is_deleted'] = 'Tin nhắn đã bị xóa, cảm ơn bạn đã phản hồi.';
$LNG['0_is_deleted'] = 'Bình luận đã được xóa, cảm ơn bạn đã phản hồi.';
$LNG['rep_comment'] = 'Bình luận';

// SIDEBAR
$LNG['groups'] = 'Nhóm';
$LNG['events'] = 'Sự kiện';
$LNG['archive'] = 'Kho lưu trữ';
$LNG['recent'] = 'Gần đây';
$LNG['all_events'] = 'Tất cả sự kiện';
$LNG['sidebar_map'] = 'Vị trí';
$LNG['sidebar_food'] = 'Bữa ăn';
$LNG['sidebar_visited'] = 'Lượt truy cập';
$LNG['sidebar_game'] = 'Trò chơi';
$LNG['sidebar_picture'] = 'Ảnh';
$LNG['sidebar_video'] = 'Videos';
$LNG['sidebar_music'] = 'Nhạc';
$LNG['sidebar_shared'] = 'Được chia sẻ';
$LNG['sidebar_pages'] = 'Trang';
$LNG['sidebar_groups'] = 'Nhóm';
$LNG['sidebar_pokes'] = 'Truyện cười';
$LNG['all_time'] = 'Mọi lúc';
$LNG['friends'] = 'Bạn bè';
$LNG['mutual' ] = 'Qua lại';
$LNG['welcome'] = 'Chào mừng';
$LNG['filter_age'] = 'Tuổi';
$LNG['all_ages'] = 'Mọi lứa tuổi';
$LNG['filter_gender'] = 'Giới tính';
$LNG['sidebar_male'] = 'Nam';
$LNG['sidebar_female'] = 'Nữ';
$LNG['all_genders'] = 'Tất cả các giới tính';
$LNG['online_friends'] = 'Bạn bè trực tuyến';
$LNG['sidebar_likes'] = 'Thích';
$LNG['sidebar_comments'] = 'Bình luận';
$LNG['sidebar_friendships'] = 'Tình bạn';
$LNG['sidebar_chats'] = 'Trò chuyện';
$LNG['sidebar_birthdays'] = 'Sinh nhật';
$LNG['sidebar_suggestions'] = 'Đề xuất của bạn bè';
$LNG['sidebar_trending'] = 'Chủ đề thịnh hành';
$LNG['sidebar_friends_activity'] = 'Hoạt động bạn bè';
$LNG['friends_birthdays'] = 'Sinh nhật';
$LNG['sidebar_people'] = 'Những người';
$LNG['sidebar_tag'] = 'Thẻ';

// MESSAGES / CHAT
$LNG['lonely_here'] = 'Ở đây rất cô đơn, làm thế nào để kết bạn?';
$LNG['chat_too_long'] = 'Xin lỗi, nhưng số ký tự tối đa được phép cho mỗi tin nhắn trò chuyện là <strong>%s</strong>.';
$LNG['blocked_by'] = 'Thông điệp này không thể được gửi đi. <strong>%s</strong> blocked you.';
$LNG['blocked_user'] = 'Thông điệp này không thể được gửi đi. Bạn đã bị chặn <strong>%s</strong>.';
$LNG['chat_self'] = 'Xin lỗi nhưng chúng tôi không thể gửi tin nhắn trò chuyện cho chính bạn.';
$LNG['chat_no_user'] = 'Bạn phải chọn một người dùng để trò chuyện.';
$LNG['view_more_conversations'] = 'Xem các cuộc trò chuyện khác';
$LNG['block'] = 'Chặn';
$LNG['unblock'] = 'Bỏ chặn';
$LNG['poke'] = 'Poke';
$LNG['poked'] = 'Truyện cười';
$LNG['conversation'] = 'Cuộc hội thoại';
$LNG['start_conversation'] = 'Bạn có thể bắt đầu cuộc trò chuyện bằng cách chọn một người từ danh sách bạn bè của mình.';
$LNG['send_message'] = 'Gửi tin nhắn';

// MESSAGE FORM
$LNG['label_food'] = 'Thêm địa điểm bạn đã ăn ở';
$LNG['label_game'] = 'Thêm một trò chơi đã chơi';
$LNG['label_visited'] = 'Thêm một địa điểm đã ghé thăm';
$LNG['label_map'] = 'Thêm một địa điểm';
$LNG['label_video'] = 'Chia sẻ phim hoặc liên kết từ YouTube hoặc Vimeo';
$LNG['label_music'] = 'Chia sẻ một bài hát hoặc một liên kết từ SoundCloud';
$LNG['label_image'] = 'Đăng tải hình ảnh';
$LNG['message_form'] = 'Bạn đang nghĩ gì vậy?';
$LNG['file_too_big'] = 'Kích thước tệp đã chọn (% s) quá lớn, kích thước tệp maxium cho phép là <strong>%s</strong>.';
$LNG['format_not_exist'] = 'Định dạng tệp (% s) đã chọn không hợp lệ, vui lòng chỉ tải lên định dạng hình ảnh <strong>% s </strong>.';
$LNG['privacy_no_exist'] = 'Quyền riêng tư đã chọn không tồn tại, vui lòng làm mới trang và thử lại.';
$LNG['event_not_exist'] = 'Sự kiện đã chọn không tồn tại, vui lòng làm mới trang và thử lại.';
$LNG['change_privacy'] = 'Ai sẽ thấy tin nhắn';

$LNG['message_too_long'] = 'Xin lỗi, nhưng số ký tự tối đa được phép cho mỗi tin nhắn là <strong>%s</strong>.';
$LNG['files_selected'] = 'các hình ảnh được chọn';
$LNG['too_many_images'] = 'Số lượng hình ảnh tối đa được phép tải lên cho mỗi tin nhắn là <strong>% s </strong>, bạn đã cố tải lên hình ảnh <strong>% s </strong>.';

// USER PANEL
$LNG['user_menu_general'] = 'Cài đặt chung';
$LNG['user_menu_security'] = 'Mật khẩu';
$LNG['user_menu_avatar'] = 'Hồ sơ';
$LNG['user_menu_notifications'] = 'Thông báo';
$LNG['user_menu_privacy'] = 'Riêng tư';
$LNG['user_menu_delete'] = $LNG['user_ttl_delete'] = 'Xóa tài khoản';
$LNG['user_menu_blocked'] = $LNG['user_ttl_blocked'] = 'Người dùng bị chặn';
$LNG['other'] = 'Khác';

$LNG['user_ttl_general'] = 'Cài đặt chung';
$LNG['user_ttl_security'] = 'Cài đặt mật khẩu';
$LNG['user_ttl_avatar'] = 'Cài đặt hồ sơ';
$LNG['user_ttl_notifications'] = 'Cài đặt thông báo';
$LNG['user_ttl_privacy'] = 'Cài đặt riêng tư';

$LNG['blocked_desc'] = 'Những người bị chặn không còn có thể nhìn thấy những thứ bạn đăng trên dòng thời gian, tin nhắn hoặc thêm bạn làm bạn.';
$LNG['delete_acc_desc'] = 'Tài khoản của bạn sẽ bị xóa vĩnh viễn cùng với tất cả nội dung liên quan của nó.';

$LNG['ttl_first_name'] = $LNG['first_name'] = 'Họ';
$LNG['sub_first_name'] = 'Nhập họ của bạn';

$LNG['ttl_last_name'] = $LNG['last_name'] = 'Tên';
$LNG['sub_last_name'] = 'Nhập tên của bạn';

$LNG['ttl_email'] = 'Email';
$LNG['sub_email'] = 'Email sẽ không được hiển thị';

$LNG['address'] = 'Địa chỉ';
$LNG['sub_address'] = 'Địa chỉ bạn sống ở';

$LNG['ttl_location'] = 'Thành Phố';
$LNG['sub_location'] = 'Thành phố bạn sống';

$LNG['ttl_website'] = 'Website';
$LNG['sub_website'] = 'Trang web, blog hoặc trang cá nhân của bạn';

$LNG['ttl_gender'] = 'Giới tính';
$LNG['sub_gender'] = 'Chọn giới tính của bạn';

$LNG['interests'] = 'Sở thích';
$LNG['sub_interested_in'] = 'Những người bạn quan tâm';

$LNG['ttl_country'] = 'Quốc gia';
$LNG['sub_country'] = 'Đất nước bạn đang sống';

$LNG['ttl_work'] = 'Nơi làm việc';
$LNG['sub_work'] = 'Nhập tên công ty nơi bạn đang làm việc';

$LNG['ttl_school'] = 'Trường học';
$LNG['sub_school'] = 'Nhập tên trường bạn đã theo học';

$LNG['ttl_profile'] = 'Hồ sơ';
$LNG['sub_profile'] = 'Xem hồ sơ';

$LNG['ttl_messages'] = 'Tin nhắn';
$LNG['sub_messages'] = 'Cách đăng tin mặc định';

$LNG['ttl_offline'] = 'Trạng thái trò chuyện';
$LNG['sub_offline'] = 'Trạng thái hiển thị cho Trò chuyện';

$LNG['ttl_facebook'] = 'Facebook';
$LNG['sub_facebook'] = 'ID hồ sơ facebook của bạn.';

$LNG['ttl_twitter'] = 'Twitter';
$LNG['sub_twitter'] = 'ID hồ sơ twitter của bạn.';

$LNG['ttl_google'] = 'Google+';
$LNG['sub_google'] = 'ID Google+ hồ sơ của bạn.';

$LNG['ttl_bio'] = 'Tiểu sử';
$LNG['sub_bio'] = 'Giới thiệu về bạn (160 ký tự trở xuống)';

$LNG['ttl_birthdate'] = 'Ngày sinh';
$LNG['sub_birthdate'] = 'Chọn ngày bạn sinh';

$LNG['ttl_upload_avatar'] = 'Tải lên hình ảnh hồ sơ đã chọn';
$LNG['ttl_delete_avatar'] = 'Xóa hình ảnh hồ sơ hiện tại của bạn';

$LNG['privacy'] = 'Riêng tư';
$LNG['public'] = 'Mọi người';
$LNG['private'] = 'Riêng tư';
$LNG['report'] = 'Báo cáo';
$LNG['delete_message'] = 'Xóa tin nhắn';
$LNG['remove_user'] = 'Gỡ người dùng';

$LNG['opt_offline_off'] = 'Trực tuyến (khi có sẵn)';
$LNG['opt_offline_on'] = 'Luôn ngoại tuyến';

$LNG['no_gender'] = 'Không có giới tính';
$LNG['male'] = 'Nam';
$LNG['female'] = 'Nữ';
$LNG['men'] = 'Trẻ em';
$LNG['women'] = 'Đàn bà';

$LNG['contact_information'] = 'Thông tin liên lạc';
$LNG['basic_information'] = 'Thông tin cơ bản';
$LNG['other_accounts'] = 'Tài khoản khác';
$LNG['work_and_education'] = 'Công việc và Giáo dục';

$LNG['ttl_upload'] = 'Đăng tải';
$LNG['ttl_new_password'] = 'mật khẩu mới';
$LNG['sub_new_password'] = 'Nhập mật khẩu mới (ít nhất 6 ký tự)';
$LNG['ttl_repeat_password'] = 'Lặp lại mật khẩu';
$LNG['sub_repeat_password'] = 'Lặp lại mật khẩu mới của bạn';
$LNG['ttl_current_password'] = 'Mật khẩu hiện tại';
$LNG['sub_current_password'] = 'Nhập mật khẩu hiện tại của bạn';
$LNG['save_changes'] = 'Lưu thay đổi';
$LNG['profile_images_desc'] = 'Nhấp vào ảnh hồ sơ hoặc bìa để thay đổi chúng';
$LNG['confirm'] = 'Xác nhận';
$LNG['approve'] = 'Chấp nhận';
$LNG['requests'] = 'Yêu cầu';
$LNG['blocked'] = 'Bị chặn';
$LNG['remove'] = 'Gỡ';
$LNG['decline'] = 'Từ chối';
$LNG['confirmed'] = 'Đã xác nhận';
$LNG['declined'] = 'Để sau';
$LNG['make_admin'] = 'Làm quản trị viên';
$LNG['remove_admin'] = 'Xóa quản trị viên';
$LNG['default'] = 'Mặc định';
$LNG['make_default'] = 'Làm mặc định';

$LNG['ttl_notificationl'] = 'Thông báo thích';
$LNG['sub_notificationl'] = 'Hiển thị cảnh báo và thông báo cho <strong> Lượt thích </strong>';

$LNG['ttl_notificationc'] = 'Thông báo bình luận';
$LNG['sub_notificationc'] = 'Hiển thị cảnh báo và thông báo cho <strong> bình luận </strong>';

$LNG['ttl_notifications'] = 'Thông báo Tin nhắn';
$LNG['sub_notifications'] = 'Hiển thị cảnh báo và thông báo cho <strong> Tin nhắn được chia sẻ </strong>';

$LNG['ttl_notificationd'] = 'Thông báo trò chuyện';
$LNG['sub_notificationd'] = 'Hiển thị cảnh báo và thông báo cho <strong> Trò chuyện </strong>';

$LNG['ttl_notificationf'] = 'Thông báo lời mời kết bạn';
$LNG['sub_notificationf'] = 'Hiển thị cảnh báo và thông báo cho <strong> đã xác nhận </strong>';

$LNG['ttl_notificationx'] = 'Thông báo trang';
$LNG['sub_notificationx'] = 'Hiển thị cảnh báo và thông báo cho lời mời <strong> Thích trang </strong>';

$LNG['ttl_notificationg'] = 'Thông báo nhóm';
$LNG['sub_notificationg'] = 'Hiển thị cảnh báo và thông báo cho <strong> Lời mời nhóm </strong>';

$LNG['ttl_notificationp'] = 'Thông báo truyện cười';
$LNG['sub_notificationp'] = 'Hiển thị cảnh báo và thông báo cho <strong> Truyện cười </strong>';

$LNG['ttl_sound_nn'] = 'Thông báo nhạc';
$LNG['sub_sound_nn'] = 'Phát âm thanh khi nhận được thông báo mới';

$LNG['ttl_sound_nc'] = 'Âm thanh trò chuyện';
$LNG['sub_sound_nc'] = 'Phát âm thanh khi nhận được tin nhắn trò chuyện mới';

$LNG['ttl_email_comment'] = 'Email về bình luận';
$LNG['sub_email_comment'] = 'Nhận email khi ai đó nhận xét về tin nhắn của bạn';

$LNG['ttl_email_like'] = 'Email về lượt thích';
$LNG['sub_email_like'] = 'Nhận email khi ai đó thích tin nhắn của bạn';

$LNG['ttl_email_new_friend'] = 'Email lời mời kết bạn';
$LNG['sub_email_new_friend'] = 'Nhận email khi ai đó gửi hoặc xác nhận yêu cầu kết bạn';

$LNG['ttl_email_page'] = 'Email thích trang';
$LNG['sub_email_page'] = 'Nhận email khi ai đó mời bạn thích một trang';

$LNG['ttl_email_group'] = 'Email mời tham gia nhóm';
$LNG['sub_email_group'] = 'Nhận email khi ai đó gửi cho bạn lời mời nhóm';

$LNG['user_ttl_sidebar'] = 'Cài đặt';

// ADMIN PANEL
$LNG['admin_login'] = 'Đăng nhập quản trị viên';
$LNG['admin_user_name'] = 'Tên người dùng';
$LNG['desc_admin_user'] = 'Nhập Tên người dùng quản trị của bạn';
$LNG['admin_pass'] = 'Mật khẩu';
$LNG['desc_admin_pass'] = 'Nhập mật khẩu người dùng quản trị của bạn';
$LNG['admin_ttl_sidebar'] = 'Lựa chọn';
$LNG['admin_menu_logout'] = 'Đăng xuất';
$LNG['admin_ttl_dashboard']			= $LNG['admin_menu_dashboard']		= 'Bảng điều khiển';
$LNG['admin_ttl_site_settings'] 	= $LNG['admin_menu_site_settings'] 	= 'Cài đặt Trang web';
$LNG['admin_ttl_themes'] 			= $LNG['admin_menu_themes'] 		= 'Giao diện';
$LNG['admin_ttl_plugins'] 			= $LNG['admin_menu_plugins'] 		= 'Bổ sung';
$LNG['admin_ttl_languages']			= $LNG['admin_menu_languages'] 		= 'Ngôn ngữ';
$LNG['admin_ttl_stats'] 			= $LNG['admin_menu_stats'] 			= 'Số liệu thống kê';
$LNG['admin_ttl_security'] 			= $LNG['admin_menu_security'] 		= 'Mật khẩu';
$LNG['admin_ttl_users'] 			= $LNG['admin_menu_users'] 			= 'Quản lý người dùng';
$LNG['admin_ttl_manage_pages']		= $LNG['admin_menu_manage_pages']	= 'Quản lý trang';
$LNG['admin_ttl_manage_groups']		= $LNG['admin_menu_manage_groups'] 	= 'Quản lý nhóm';
$LNG['admin_ttl_manage_reports']	= $LNG['admin_menu_manage_reports'] = 'Quản lý báo cáo';
$LNG['admin_ttl_manage_ads']		= $LNG['admin_menu_manage_ads'] 	= 'Quảng lý quảng cáo';
$LNG['admin_ttl_info_pages']		= $LNG['admin_menu_info_pages'] 	= 'Trang thông tin';

$LNG['list_users'] = 'Tất cả người sử dụng';
$LNG['list_moderators'] = 'Người điều hành';
$LNG['list_verified'] = 'Đã xác minh';
$LNG['list_suspended'] = 'Cấm';

$LNG['title'] = 'Tiêu đề';
$LNG['admin_sub_title'] = 'Tiêu đề của trang web';

$LNG['logo'] = 'Logo';
$LNG['admin_sub_logo'] = 'Logo của trang web (định dạng PNG)';

$LNG['admin_ttl_captcha'] = 'Captcha';
$LNG['admin_sub_captcha'] = 'Bật hình ảnh xác thực khi đăng ký';

$LNG['admin_ttl_timestamp'] = 'Thời gian';
$LNG['admin_sub_timestamp'] = 'Loại dấu thời gian Tin nhắn, Nhận xét và Trò chuyện';

$LNG['admin_ttl_timezone'] = 'Múi giờ';
$LNG['admin_sub_timezone'] = 'Múi giờ được hỗ trợ bởi PHP';

$LNG['admin_sub_pages'] = 'Bật chức năng của Trang';
$LNG['admin_sub_groups'] = 'Bật chức năng Nhóm';

$LNG['admin_ttl_msg_perpage'] = 'Tin nhắn';
$LNG['admin_sub_msg_perpage'] = 'Số lượng tin nhắn trên mỗi trang';

$LNG['admin_ttl_com_perpage'] = 'Bình luận';
$LNG['admin_sub_com_perpage'] = 'Số lượng bình luận trên mỗi bài';

$LNG['admin_ttl_chat_perpage'] = 'Trò chuyện';
$LNG['admin_sub_chat_perpage'] = 'Số lượng cuộc trò chuyện trên mỗi trang';

$LNG['admin_ttl_smiles'] = 'Biểu tượng cảm xúc';
$LNG['admin_sub_smiles'] = 'Cho phép và chuyển đổi các mã ngắn trên Tin nhắn, Nhận xét và Trò chuyện thành biểu tượng cảm xúc';

$LNG['admin_ttl_permalinks'] = 'Liên kết Perma';
$LNG['admin_sub_permalinks'] = 'Bật cấu trúc URL liên kết cố định (example.com/profile/username)';

$LNG['admin_ttl_email_activation'] = 'Kích hoạt Email';
$LNG['admin_sub_email_activation'] = 'Yêu cầu tài khoản được kích hoạt qua email';

$LNG['admin_ttl_nperpage'] = 'Thông báo';
$LNG['admin_sub_nperpage'] = 'Số lượng thông báo sẽ được hiển thị (Trang thông báo)';

$LNG['admin_ttl_msg_limit'] = 'Ký tự tin nhắn';
$LNG['admin_sub_msg_limit'] = 'Số lượng ký tự được phép cho mỗi tin nhắn';

$LNG['admin_ttl_chat_limit'] = 'Ký tự trò chuyện';
$LNG['admin_sub_chat_limit'] = 'Số lượng ký tự được phép cho mỗi cuộc hội thoại';

$LNG['admin_ttl_email_reg'] = 'Email khi đăng ký';
$LNG['admin_sub_email_reg'] = 'Gửi email cho người dùng khi đăng ký';

$LNG['admin_ttl_notificationsm'] = 'Thông báo Tin nhắn';
$LNG['admin_sub_notificationsm'] = 'Khoảng thời gian cập nhật để kiểm tra tin nhắn mới (tính bằng giây)';

$LNG['admin_ttl_notificationsn'] = 'Thông báo sự kiện';
$LNG['admin_sub_notificationsn'] = 'Khoảng thời gian cập nhật để kiểm tra các thông báo sự kiện mới (tính bằng giây)';

$LNG['admin_ttl_chatrefresh'] = 'Làm mới trò chuyện';
$LNG['admin_sub_chatrefresh'] = 'Thời gian tần suất cửa sổ trò chuyện cập nhật tin nhắn mới (tính bằng giây)';

$LNG['admin_ttl_timeonline'] = 'Người dùng trực tuyến';
$LNG['admin_sub_timeonline'] = 'Lượng thời gian được coi là trực tuyến kể từ hoạt động của người dùng cuối cùng (tính bằng giây)';

$LNG['admin_ttl_image_profile'] = 'Kích thước hình ảnh (Hồ sơ)';
$LNG['admin_sub_image_profile'] = 'Kích thước ảnh được phép tải lên (ảnh hồ sơ, ảnh bìa hồ sơ, ảnh bìa nhóm) (tính bằng MB)';

$LNG['admin_ttl_image_format'] = 'Định dạng Hình ảnh (Hồ sơ)';
$LNG['admin_sub_image_format'] = 'Định dạng ảnh được phép tải lên (ảnh hồ sơ, ảnh bìa hồ sơ, ảnh bìa nhóm), chỉ sử dụng gif, png, jpg các định dạng khác không được hỗ trợ';

$LNG['admin_ttl_message_image'] = 'Kích thước hình ảnh (Tin nhắn)';
$LNG['admin_sub_message_image'] = 'Kích thước hình ảnh được phép tải lên (Tin nhắn) (tính bằng MB)';

$LNG['admin_ttl_message_format'] = 'Định dạng hình ảnh (Tin nhắn)';
$LNG['admin_sub_message_format'] = 'Định dạng hình ảnh được phép tải lên (Tin nhắn), chỉ sử dụng gif, png, jpg các định dạng khác không được hỗ trợ';

$LNG['admin_sub_friends_limit'] = 'Số lượng tình bạn tối đa được phép cho mỗi người dùng';
$LNG['admin_sub_pages_limit'] = 'Số lượng trang được tạo tối đa cho mỗi người dùng';
$LNG['admin_sub_groups_limit'] = 'Số lượng nhóm được tạo và tham gia tối đa cho mỗi người dùng';

$LNG['admin_ttl_censor'] = 'Kiểm duyệt';
$LNG['admin_sub_censor'] = 'Các từ được kiểm duyệt (ví dụ: word1, word2, word3)';

$LNG['email_providers'] = 'Nhà cung cấp Email';
$LNG['sub_email_providers'] = 'Cho phép đăng ký với các nhà cung cấp email nhất định (ví dụ: domain.com, domain.org)';

$LNG['admin_ttl_ad1'] = 'Đơn vị quảng cáo 1';
$LNG['admin_sub_ad1'] = 'Đơn vị quảng cáo 1 (Dưới cùng [Trang chào mừng])';

$LNG['admin_ttl_ad2'] = 'Đơn vị quảng cáo 2';
$LNG['admin_sub_ad2'] = 'Đơn vị quảng cáo 2 (Dưới cùng [Trang chào mừng])';

$LNG['admin_ttl_ad3'] = 'Đơn vị quảng cáo 3';
$LNG['admin_sub_ad3'] = 'Đơn vị quảng cáo 3 (Dưới cùng [Trang chào mừng])';

$LNG['admin_ttl_ad4'] = 'Đơn vị quảng cáo 4';
$LNG['admin_sub_ad4'] = 'Đơn vị quảng cáo 4 (Dưới cùng [Trang chào mừng])';

$LNG['admin_ttl_ad5'] = 'Đơn vị quảng cáo 5';
$LNG['admin_sub_ad5'] = 'Đơn vị quảng cáo 5 (Dưới cùng [Trang chào mừng])';

$LNG['admin_ttl_ad6'] = 'Đơn vị quảng cáo 6';
$LNG['admin_sub_ad6'] = 'Đơn vị quảng cáo 6 (Dưới cùng [Trang chào mừng])';

$LNG['admin_ttl_fbapp'] = 'Đăng nhập Facebook';
$LNG['admin_sub_fbapp'] = 'Cho phép người dùng đăng nhập bằng Facebook';

$LNG['admin_ttl_fbappid'] = 'ID ứng dụng';
$LNG['admin_sub_fbappid'] = 'ID ứng dụng Facebook';

$LNG['admin_ttl_fbappsecret'] = 'Ứng dụng bí mật'; 
$LNG['admin_sub_fbappsecret'] = 'Bí mật ứng dụng Facebook';

$LNG['smtp_emails'] = 'Thư SMTP';
$LNG['smtp_sub_emails'] = 'Cho phép gửi email qua SMTP';

$LNG['smtp_host'] = 'SMTP Host';
$LNG['smtp_sub_host'] = 'Các SMTP Host';

$LNG['smtp_port'] = 'SMTP Port';
$LNG['smtp_sub_port'] = 'Các SMTP Port';

$LNG['smtp_auth'] = 'Xác thực SMTP';
$LNG['smtp_sub_auth'] = 'Bật xác thực SMTP';

$LNG['smtp_username'] = 'Tên người dùng SMTP';
$LNG['smtp_sub_username'] = 'Tên người dùng SMTP';

$LNG['smtp_password'] = 'Mật khẩu SMTP';
$LNG['smtp_sub_password'] = 'Mật khẩu SMTP';

$LNG['admin_ttl_edit'] = 'Sửa';
$LNG['admin_ttl_edit_profile'] = 'Sửa hồ sơ';

$LNG['admin_ttl_delete'] = 'Xóa';
$LNG['admin_ttl_delete_profile'] = 'Xóa hồ sơ';

$LNG['admin_ttl_mail'] = 'Email';
$LNG['admin_ttl_username'] = 'tên người dùng';
$LNG['admin_ttl_id'] = 'ID'; // As in user ID

$LNG['admin_ttl_email_comment'] = 'Gửi email về bình luận';
$LNG['admin_sub_email_comment'] = 'Cho phép gửi email khi ai đó bình luận vào một bài đăng (ghi đè cài đặt của người dùng)';

$LNG['admin_ttl_email_like'] = 'Gửi email trên Like';
$LNG['admin_sub_email_like'] = 'Cho phép gửi email khi ai đó thích một tin nhắn (ghi đè cài đặt của người dùng)';

$LNG['admin_ttl_email_new_friend'] = 'Gửi email về tình bạn';
$LNG['admin_sub_email_new_friend'] = 'Cho phép gửi email khi ai đó gửi hoặc xác nhận yêu cầu kết bạn (ghi đè cài đặt của người dùng)';

$LNG['admin_ttl_email_page'] = 'Thư mời trang qua email';
$LNG['admin_sub_email_page'] = 'Cho phép gửi email khi ai đó gửi một trang giống như lời mời (ghi đè cài đặt của người dùng)';

$LNG['admin_ttl_email_group'] = 'Thư mời nhóm qua email';
$LNG['admin_sub_email_group'] = 'Cho phép gửi email khi ai đó gửi lời mời nhóm (ghi đè cài đặt của người dùng)';

$LNG['admin_ttl_ilimit'] = 'Hình ảnh (Tin nhắn)';
$LNG['admin_sub_ilimit'] = 'Số hình ảnh tối đa được phép tải lên cho mỗi tin nhắn';

$LNG['admin_ttl_wholiked'] = 'Người thích';
$LNG['admin_sub_wholiked'] = 'Số lượng ảnh hồ sơ được hiển thị gần số lượt thích';

$LNG['admin_ttl_sperpage'] = 'Người dùng';
$LNG['admin_sub_sperpage'] = 'Số lượng người dùng được hiển thị trên mỗi trang (Hồ sơ Bạn bè, Người dùng Nhóm)';

$LNG['admin_ttl_aperip'] = 'Tài khoản';
$LNG['admin_sub_aperip'] = 'Số lượng tài khoản được phép đăng ký trên mỗi IP (0 cho không giới hạn)';

$LNG['admin_ttl_ronline'] = 'Bạn bè trực tuyến';
$LNG['admin_sub_ronline'] = 'Số lượng bạn bè trực tuyến được hiển thị trên trang Nguồn cấp dữ liệu / Đăng ký (thanh bên).';

$LNG['admin_ttl_nperwidget'] = 'Thông báo thả xuống';
$LNG['admin_sub_nperwidget'] = 'Số lượng thông báo được hiển thị trên mỗi danh mục (lượt thích, bình luận, tin nhắn, lượt chia sẻ, yêu cầu kết bạn)';


$LNG['admin_ttl_uperpage'] = 'Quảng trị viên';
$LNG['admin_sub_uperpage'] = 'Số lượng người dùng trên mỗi trang (Quản lý các phần)';

$LNG['admin_sub_verified'] = 'Hồ sơ người dùng được xác minh theo mặc định? (Không được khuyến khích)';
$LNG['admin_sub_tracking'] = 'Mã theo dõi phân tích';

$LNG['join_date'] = 'Ngày tham gia';
$LNG['user_group'] = 'Nhóm người dùng';
$LNG['ttl_verified'] = 'Đã xác minh';


$LNG['sub_verified'] = 'Trạng thái đã xác minh tài khoản';
$LNG['sub_group'] = 'Nhóm tài khoản';
$LNG['sub_suspended'] = 'Trạng thái nghi ngờ tài khoản';

$LNG['page_title'] = 'Tiêu đề trang';
$LNG['page_url'] = 'URL trang';
$LNG['public_page'] = 'Trang công khai';
$LNG['page_content'] = 'Trang nội dung';

$LNG['sub_page_title'] = 'Tiêu đề trang (hỗ trợ chuỗi có thể dịch được)';
$LNG['sub_page_url'] = 'URL của trang (không có ký tự đặc biệt)';
$LNG['sub_public_page'] = 'Hiển thị trang trong chân trang và thanh bên';
$LNG['sub_page_content'] = 'Nội dung trang (hỗ trợ chuỗi có thể dịch được)';
$LNG['url_exists'] = 'URL trang này đã tồn tại';

$LNG['per_page'] = '/ Trang';
$LNG['per_ip'] = '/ IP';
$LNG['second'] = 'Giây';
$LNG['seconds'] = 'Giây';
$LNG['minute'] = 'Phút';
$LNG['minutes'] = 'Phút';
$LNG['hour'] = 'Giờ';
$LNG['recommended'] = 'Khuyến khích';
$LNG['edit_user'] = 'Sửa người dùng';
$LNG['username_to_edit'] = 'Tên tài khoản';
$LNG['username_to_edit_sub'] = 'Nhập tên người dùng bạn muốn chỉnh sửa';
$LNG['group_to_edit'] = 'Tên nhóm';
$LNG['group_to_edit_sub'] = 'Nhập tên nhóm bạn muốn chỉnh sửa';
$LNG['page_to_edit'] = 'Tên trang';
$LNG['page_to_edit_sub'] = 'Nhập tên trang bạn muốn chỉnh sửa';
$LNG['chat_smiles'] = 'Thêm biểu tượng cảm xúc';
$LNG['chat_picture'] = 'Tải lên hình ảnh';
$LNG['chat_camera'] = 'Chụp ảnh';

// STATS
$LNG['likes'] = 'Thích';
$LNG['messages'] = 'Tin nhắn';
$LNG['comments'] = 'Bình luận';
$LNG['registered_users'] = 'Đăng ký người dùng';
$LNG['today'] = 'Hôm nay';
$LNG['this_week'] = 'This Week';
$LNG['this_month'] = 'This Month';
$LNG['this_year'] = 'This Year';
$LNG['total'] = 'Tổng cộng';
$LNG['total_likes'] = 'Tổng cộng lượt thích';
$LNG['date'] = 'Date';
$LNG['evolution'] = 'Sự phát triển';

$LNG['reports'] = 'Báo cáo';
$LNG['total_reports'] = 'Tổng cộng báo cáo';
$LNG['pending_reports'] = 'Báo cáo đang chờ xử lý';
$LNG['safe_reports'] = 'Báo cáo an toàn';
$LNG['deleted_reports'] = 'Xóa báo cáo';

// DASHBOARD
$LNG['admin_panel'] = 'Bảng điều khiển quản trị';
$LNG['at_a_glance'] = 'Trong nháy mắt';
$LNG['site_info'] = 'Thông tin trang';
$LNG['site_version'] = '<a href="%s" target="_blank">%s</a> %s';
$LNG['site_loaded'] = 'Giao diện <a href="%s" rel="loadpage">%s</a> với <a href="%s" rel="loadpage">%s bổ sung</a> được kích hoạt';
$LNG['online_users'] = 'Người dùng trực tuyến';
$LNG['users'] = 'Người dùng';
$LNG['moderators'] = 'Người điều hành';
$LNG['shares'] = 'Chia sẻ';
$LNG['useful_links'] = 'Liên kết hữu ích';
$LNG['get_themes'] = 'Nhận thêm chủ đề';
$LNG['get_plugins'] = 'Nhận thêm các plugin';
$LNG['get_languages'] = 'Nhận thêm ngôn ngữ';

// MANAGE REPORTS
$LNG['admin_reports_ignore'] = 'Bỏ qua báo cáo và đánh dấu nội dung là an toàn';
$LNG['admin_reports_delete'] = 'Xóa báo cáo và nội dung đã báo cáo';
$LNG['admin_reports_view'] = 'Xem nội dung được báo cáo';

// LIKES
$LNG['like'] = 'Thích';
$LNG['dislike'] = 'Bỏ thích';
$LNG['liked'] = 'Thích';
$LNG['liked_this'] = 'Thích cái này';
$LNG['view_all_likes'] = 'Xem tất cả lượt thích';
$LNG['people_who_like_this'] = 'Những người thích điều này';

// MISC
$LNG['sponsored'] = 'Được tài trợ';
$LNG['censored'] = '<strong>kiểm duyệt</strong>';
$LNG['new_like_notification'] = '<a href="%s" rel="loadpage">%s</a> thích của bạn <a href="%s" rel="loadpage">tin nhắn</a>';
$LNG['new_like_c_notification'] = '<a href="%s" rel="loadpage">%s</a> thích của bạn <a href="%s" rel="loadpage">bình luận</a>';
$LNG['new_poke_notification'] = '<a href="%s" rel="loadpage">%s</a> chọc bạn';
$LNG['new_comment_notification'] = '<a href="%s" rel="loadpage">%s</a> đã bình luận về bạn <a href="%s" rel="loadpage">tin nhắn</a>';
$LNG['new_shared_notification'] = '<a href="%s" rel="loadpage">%s</a> đã chia sẻ của bạn <a href="%s" rel="loadpage">tin nhắn</a>';
$LNG['new_page_notification'] = '<a href="%s" rel="loadpage">%s</a> đã mời bạn thích <a href="%s" rel="loadpage">%s</a> trang';
$LNG['new_group_notification'] = '<a href="%s" rel="loadpage">%s</a> đã mời bạn tham gia <a href="%s" rel="loadpage">%s</a> nhóm';
$LNG['new_friend_notification'] = '<a href="%s" rel="loadpage">%s</a> chấp nhận yêu cầu kết bạn của bạn';
$LNG['new_chat_notification'] = '<a href="%s" rel="loadpage">%s</a> đã gửi cho bạn một <span class="desktop"><a onclick="%s">tin nhắn trò chuyện</a></span><span class="mobile"><a href="%s" rel="loadpage">tin nhắn trò chuyện</a></span>';
$LNG['new_birthday_notification'] = '<a href="%s" rel="loadpage">%s</a>\'s sinh nhật';
$LNG['years_old'] = '%s tuổi';
$LNG['x_and_x_others'] = '<a href="%s" rel="loadpage">%s</a> và <a href="%s" rel="loadpage">%s hơn</a>';
$LNG['new_like_fa'] = '<a href="%s" rel="loadpage">%s</a> thích một <a href="%s" rel="loadpage">tin nhắn</a>';
$LNG['new_like_c_fa'] = '<a href="%s" rel="loadpage">%s</a> thích một <a href="%s" rel="loadpage">bình luận</a>';
$LNG['new_comment_fa'] = '<a href="%s" rel="loadpage">%s</a> đã bình luận về một <a href="%s" rel="loadpage">tin nhắn</a>';
$LNG['new_message_fa'] = '<a href="%s" rel="loadpage">%s</a> đã đăng một cái mới <a href="%s" rel="loadpage">tin nhắn</a>';
$LNG['change_password'] = 'Đổi mật khẩu';
$LNG['enter_new_password'] = 'Nhập mật khẩu mới của bạn';
$LNG['enter_reset_key'] = 'Nhập khóa đặt lại';
$LNG['enter_username'] = 'Điền tên đăng nhập';
$LNG['reset_key'] = 'Đặt lại chìa khoá';
$LNG['new_password'] = 'mật khẩu mới';
$LNG['password_recovery'] = 'Khôi phục mật khẩu';
$LNG['recover']	= 'Khôi phục';
$LNG['recover_sub_username'] = 'Nhập tên người dùng hoặc email bạn muốn khôi phục mật khẩu';
$LNG['tracking_code'] = 'Mã theo dõi';
$LNG['friends_limit'] = 'Bạn đã đạt đến giới hạn bạn bè';
$LNG['user_friends_limit'] = 'Người dùng này đã đạt đến giới hạn bạn bè';
$LNG['last_online'] = 'Đã xem: %s';

// PAGE
$LNG['create_page'] = 'Tạo trang';
$LNG['edit_page'] = 'Sửa trang';
$LNG['delete_page'] = 'Xóa trang';
$LNG['page_sub_name'] = 'Tên trang (sẽ xuất hiện trong URL)';
$LNG['page_sub_title'] = 'Tiêu đề trang (sẽ xuất hiện trên tiêu đề của trang';
$LNG['page_sub_description'] = 'Mô tả trang';
$LNG['page_sub_website'] = 'URL trang web';
$LNG['profile_image'] = 'Hình ảnh hồ sơ cá nhân';
$LNG['cover_image'] = 'Ảnh bìa';
$LNG['page_sub_pimg'] = 'Hình ảnh hồ sơ trang';
$LNG['page_sub_cover'] = 'Hình ảnh trang bìa';
$LNG['category'] = 'Loại';
$LNG['page_sub_category'] = 'Loại trang';
$LNG['phone'] = 'Điện thoại';
$LNG['page_sub_phone'] = 'Số điện thoại';
$LNG['page_sub_address'] = 'Địa chỉ';

$LNG['page_name_consist'] = 'Tên trang chỉ có thể chứa các chữ cái và số';
$LNG['page_name_taken'] = 'Tên trang này đã được sử dụng';
$LNG['page_name_less'] = 'Tên trang phải ít hơn %s ký tự';
$LNG['page_title_less'] = 'Tiêu đề trang phải ít hơn %s ký tự';
$LNG['page_desc_less'] = 'Mô tả trang phải ít hơn %s ký tự';
$LNG['invalid_phone'] = 'Số điện thoại chỉ được chứa các chữ số, dấu cộng (+) và dấu trừ (-).';
$LNG['page_delete_desc'] = 'Xóa một trang cũng sẽ xóa các tin nhắn của nó cùng với nội dung của chúng.';
$LNG['page_deleted'] = 'Trang <strong> %s </strong> đã bị xóa';
$LNG['page_maximum'] = 'Bạn đã vượt quá số lượng trang tối đa được phép (%s).';
$LNG['group_maximum'] = 'Bạn đã vượt quá số lượng nhóm tối đa được phép (%s).';

// PAGE CATEGORIES
$LNG['select_category'] = 'Select a category';
$LNG['page_1'] = 'Local Business or Place';
$LNG['page_2'] = 'Company, Organization or Institution';
$LNG['page_3'] = 'Brand or Product';
$LNG['page_4'] = 'Artist, Band or Public Figure';
$LNG['page_5'] = 'Entertainment';
$LNG['page_6'] = 'Cause or Community';

// GROUP
$LNG['create_group'] = 'Create Group';
$LNG['edit_group'] = 'Edit Group';
$LNG['leave_group'] = 'Leave Group';
$LNG['delete_group'] = 'Delete Group';
$LNG['discussion'] = 'Discussion';
$LNG['members'] = 'Members';
$LNG['admins'] = 'Admins';
$LNG['page'] = 'Page';
$LNG['group'] = 'Group';
$LNG['group_private'] = 'Sorry, but this group is private, only the member of this group can view the content.';
$LNG['group_private_ttl'] = 'Private Group';
$LNG['name'] = 'Name';
$LNG['any_member'] = 'Any member';
$LNG['posts'] = 'Posts';
$LNG['group_sub_name'] = 'The group name (will appear in URL)';
$LNG['group_sub_title'] = 'The group title (will appear on the group\'s title)';
$LNG['group_sub_privacy'] = 'The group privacy';
$LNG['group_sub_description'] = 'The group description';
$LNG['group_sub_posts'] = 'Who can post in the group';
$LNG['admins_posts'] = ', only admins can post';
$LNG['members_posts'] = ', any member can post';
$LNG['group_sub_cover'] = 'The group cover image';
$LNG['public_group'] = 'Public Group';
$LNG['private_group'] = 'Private Group';
$LNG['x_members'] = '%s members';
$LNG['join_group'] = 'Join Group';
$LNG['pending_approval'] = 'Pending Approval';
$LNG['search_this_group'] = 'Search this group';
$LNG['invited'] = 'Invited';
$LNG['member'] = 'Member';
$LNG['invite'] = 'Invite';

$LNG['group_name_consist'] = 'Group name can only contain letters and numbers';
$LNG['group_name_taken'] = 'This group name is already taken';
$LNG['group_name_less'] = 'Group name should be less than %s characters';
$LNG['group_title_less'] = 'Group title should be less than %s characters';
$LNG['group_desc_less'] = 'Group description should be less than %s characters';
$LNG['group_delete_desc'] = 'Deleting a group will also delete its messages along with their content.';
$LNG['group_deleted'] = 'The group <strong>%s</strong> has been deleted';

$LNG['invite_friends'] = 'Invite Friends';

// PROFILE
$LNG['profile_not_exists'] = 'Sorry, but this profile does not exists.';
$LNG['group_not_exists'] = 'Sorry, but this group does not exists.';
$LNG['page_not_exists'] = 'Sorry, but this page does not exists.';
$LNG['profile_semi_private'] = 'Sorry, but this profile is private, only the friends of this user can view the profile.';
$LNG['profile_private'] = 'Sorry, but this profile is completely private.';
$LNG['profile_suspended'] = 'Sorry, but this profile has been suspended.';
$LNG['profile_not_exists_ttl'] = 'Profile does not exists.';
$LNG['group_not_exists_ttl'] = 'Group does not exists.';
$LNG['profile_semi_private_ttl'] = 'Private profile';
$LNG['profile_private_ttl'] = 'Private profile';
$LNG['profile_suspended_ttl'] = 'Suspended Profile';
$LNG['profile_blocked'] = 'Sorry, but you have blocked or been blocked by this user.';
$LNG['profile_blocked_ttl'] = 'Blocked profile';
$LNG['add_friend'] = 'Add as friend';
$LNG['remove_friend'] = 'Remove friend';
$LNG['friend_request_sent'] = 'Friend request sent';
$LNG['friend_request_accept'] = 'Accept friend request';
$LNG['created_on'] = 'Created on';
$LNG['description'] = 'Description';
$LNG['profile_about'] = 'About';
$LNG['profile_birthdate'] = 'Birthdate';
$LNG['lives_in'] = 'Lives in';
$LNG['born_on'] = 'Born on';
$LNG['studied_at'] = 'Studied at';
$LNG['works_at'] = 'Works at';
$LNG['profile_view_site'] = 'View website';
$LNG['profile_view_profile'] = 'View Profile';
$LNG['profile_bio']	= 'Bio';
$LNG['verified_page'] = 'Verified Page';
$LNG['edit_profile_cover'] = 'Change Profile Images';
$LNG['view_all_notifications'] = 'View More Notifications';
$LNG['view_chat_notifications'] = 'View More Messages';
$LNG['view_confirmed_friendships'] = 'View confirmed requests';
$LNG['close_notifications'] = 'Close Notifications';
$LNG['notifications_settings'] = 'Notifications Settings';
$LNG['no_notifications'] = 'No notifications';
$LNG['search_title'] = 'Search Results';
$LNG['view_all_results'] = 'View All Results';
$LNG['close_results'] = 'Close Results';
$LNG['no_results'] = 'No results available. Try another search.';
$LNG['no_results_ttl'] = 'Search Results';
$LNG['search_for_users'] = 'Search for users';
$LNG['search_in_friends'] = 'Search in friends';
$LNG['type_message'] = 'Type a message...';
$LNG['follows'] = 'Follows';
$LNG['followed_by'] = 'Followed by';
$LNG['people'] = 'people';
$LNG['no_info_avail'] = 'No information available';
$LNG['account_suspended'] = 'This account is currently suspended.';
$LNG['account_not_activated'] = 'This account is not activated. <a href="%s">Click here</a> to resend the activation email.';
$LNG['re_activate_already'] = 'An activation email has already been sent today';
$LNG['re_activate_sent'] = 'An activation email has been sent';

// GENERAL
$LNG['title_profile'] = 'Profile';
$LNG['title_feed'] = 'News Feed';
$LNG['title_post'] = 'Post';
$LNG['title_messages'] = 'Messages';
$LNG['title_settings'] = 'Settings';
$LNG['title_search'] = 'Search';
$LNG['title_notifications'] = 'Notifications';
$LNG['title_page'] = 'Create Page';
$LNG['title_group'] = 'Create Group';
$LNG['title_admin']	= 'Admin';
$LNG['edit'] = 'Edit';
$LNG['delete'] = 'Delete';
$LNG['suspended'] = 'Suspended';
$LNG['ignore'] = 'Ignore';
$LNG['view'] = 'View';
$LNG['timeline'] = 'Timeline';
$LNG['on'] = 'On';
$LNG['off'] = 'Off';
$LNG['yes'] = 'Yes';
$LNG['no'] = 'No';
$LNG['none'] = 'None';
$LNG['pages'] = 'Pages';
$LNG['search_for_people'] = 'Search';
$LNG['search_pages'] ;
$LNG['search_groups'] ;
$LNG['new_message'] ;
$LNG['privacy_policy'] = 'Privacy Policy';
$LNG['terms_of_use'] = 'Terms of Use';
$LNG['about'] = 'About';
$LNG['disclaimer'] = 'Disclaimer';
$LNG['contact'] = 'Contact';
$LNG['developers'] = 'Developers';
$LNG['language'] = 'Language';

// TIME
$LNG['just_now'] = 'just now';
$LNG['ta_second'] = 'a second';
$LNG['ta_seconds'] = '%d seconds';
$LNG['ta_minute'] = 'a minute';
$LNG['ta_minutes'] = '%d minutes';
$LNG['ta_hour'] = 'an hour';
$LNG['ta_hours'] = '%d hours';
$LNG['ta_day'] = 'a day';
$LNG['ta_days'] = '%d days';
$LNG['ta_week'] = 'a week';
$LNG['ta_weeks'] = '%d weeks';
$LNG['ta_month'] = 'a month';
$LNG['ta_months'] = '%d months';
$LNG['ta_year'] = 'a year';
$LNG['ta_years'] = '%d years';
$LNG['ago'] = 'ago';

// MONTHS
$LNG['month'] = 'Month';
$LNG['year'] = 'Year';
$LNG['day'] = 'Day';
$LNG['month_1'] = 'January';
$LNG['month_2'] = 'February';
$LNG['month_3'] = 'March';
$LNG['month_4'] = 'April';
$LNG['month_5'] = 'May';
$LNG['month_6'] = 'June';
$LNG['month_7'] = 'July';
$LNG['month_8'] = 'August';
$LNG['month_9'] = 'September';
$LNG['month_10'] = 'October';
$LNG['month_11'] = 'November';
$LNG['month_12'] = 'December';
?>