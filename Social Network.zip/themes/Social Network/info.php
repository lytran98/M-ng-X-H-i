<?php
// Theme Name
$name = 'Lý Trần';

// Theme Author
$author = 'Lý Trần';

// Theme URL
$url = 'https://lytran98.github.io/lytran.com';

// Theme Version
//$version = '1.4.9';
?>